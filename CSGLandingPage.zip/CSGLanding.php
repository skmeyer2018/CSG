<!DOCTYPE html>
<html>
    <head>
        <title>ESPRESSO EXPRESS COFFEE CO - landing and contact page</title>
        <meta name="description" content="A job application assessment provided by CSG (Consulting Services Group), Herndon, VA, and assigned to Stephen Kleimeyer">
        <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Michroma">
          <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Arima">
          <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Caveat">
          <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Gugi">
        <style>
             
            .slogan {
                width: 100%;
                height: 4rem;
                overflow: hidden;
                border: 1px solid black;
                padding: 0;
                margin-bottom: 16px;
            }

            .picture-text {
                width: 100%;
                height: 4rem;
                overflow: hidden;
                padding: 0;
            }

            .moving-picture-text{
                animation:3s anim-moving-text ease infinite;
            }
            
           @keyframes anim-moving-text {
             0%{
                transform: translate(25px, 100px);
                    }
                    25%{
                transform: translate(25px, 80px);
                    }   
                    50%{
                transform: translate(25px, 50px);
                    }   
                    75%{
                transform: translate(25px, 20px);
                    }  
                    100%{
                transform: translate(25px, 10px);
                    }               
                    
           }
           
             .text-contents {
                margin-left: 50px;
                font-weight:bold;
                font-family: Arima;
                column-count:3;
                column-width:75px;

             }  
             .pop-out-in-text {
                font-family:Caveat;
                color:blue;
                animation: 2s anim-popoutin ease infinite;
             }
            

            @keyframes anim-popoutin {
                0% {
                    color: black;
                    transform: scale(0);
                    opacity: 0;
                    text-shadow: 0 0 0 rgba(0, 0, 0, 0);
                    }
                25% {
                    color: blue;
                    transform: scale(2);
                    opacity: 1;
                    text-shadow: 3px 10px 5px rgba(0, 0, 0, 0.5);
                    }
                50% {
                    color: black;
                    transform: scale(1);
                    opacity: 1;
                    text-shadow: 1px 0 0 rgba(0, 0, 0, 0);
                    }
                100% {
                    /* animate nothing to add pause at the end of animation */
                    color:blue;
                    transform: scale(1);
                    opacity: 1;
                    text-shadow: 1px 0 0 rgba(0, 0, 0, 0);
                    }
                }

            
             input[type=text] {
                border-color:black;
                border-width:3px;
             }
             input[type=email] {
                border-color:black;
                border-width:3px;
             }
        </style>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script> 
    </head>
 
<body>
 <table>  
    <tr>
<td id="imgCol"><img id="logoAnimation" src="images/LogoAnimation.gif" height="100" width="200" style="margin:30px;"></td>
<td><h1 style="font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bold; font-size:50px; color:red;">Espresso Express Co</h1></td>
<td><p id="timePosition" style="font-weight:bold; font-size: 30px; padding:50px; font-family:Gugi"></p></td>
    </tr>
</table> 
<center>
<div class="slogan">
  <h2 class="pop-out-in-text">The brew from us to you right out of the blue</h2>
</div>
</center>
<hr style="color:black; height:2px; background-color: black; border-width:4px;">
<center><img src="images/HaymarketBackyard.jpg" height="300" width="1100" style="top:0%; "></center>
<div class="picture-text"style="position:absolute; top:300px; left:350px;">
<h1 class="moving-picture-text" style="color:white; font-family:Michroma; ">A gorgeous day in the meadow.</h1>
            </div>   

<p class="text-contents">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin in rhoncus velit, non posuere urna. 
    Ut ac quam libero. Vestibulum a dolor sit amet erat pulvinar rhoncus. Suspendisse at mauris vitae mauris congue volutpat sit amet ac augue. 
    Sed tempor imperdiet est nec ultrices. Integer vel tortor ornare massa viverra auctor.
     Nullam vulputate mi est, sit amet varius nibh venenatis sed. In commodo luctus lobortis. Suspendisse pulvinar lobortis mauris. 
     Vivamus euismod, metus vitae efficitur pellentesque, nibh libero gravida dui, quis tincidunt orci felis quis felis. Aenean volutpat at odio id tempus.
</p>

    <h2>Sign-up for our Mailing List</h2>
<div style="width:600px; background-color:skyblue;padding:60px;">
<form method="POST" action="NewContactConfirm.php" >
<div class="form-group">
      <label for="FirstName">First Name:</label>
      <input type="text" class="form-control" id="FirstName" placeholder="Enter first Name" name="FirstName">
      <label for="LastName">Last Name:</label>
      <input type="text" class="form-control" id="LastName" placeholder="Enter last name" name="LastName">
      <label for="Address">Address:</label>
      <input type="text" class="form-control" id="Address" placeholder="Enter address" name="Address">     
      <label for="City">City:</label>
      <input type="text" class="form-control" id="City" placeholder="Enter city" name="City">
      <label for="State">State:</label>
  <select name="State" id="State" >
    <option  value="AL">AL</option>
    <option  value="AK">AK</option>
    <option   value="AR">AR</option>
    <option   value="AZ">AZ</option>
    <option   value="CA">CA</option>
    <option   value="CO">CO</option>
    <option   value="CT">CT</option>  
    <option   value="DE">DE</option>
    <option   value="DC">DC</option>
    <option   value="FL">FL</option>
    <option  value="GA" >GA</option>
    <option value="HI" >HI</option>
    <option  value="ID">ID</option>
    <option value="IL" >IL</option>
    <option  value="IN">IN</option>
    <option  value="IA">IA</option>
    <option value="KS" >KS</option>
    <option  value="KY">KY</option>
    <option  value="LA">LA</option>
    <option value="MA" >MA</option>
    <option value="MD" >MD</option>
    <option value="ME" >ME</option>
    <option value="MI" >MI</option>
    <option value="MN" >MN</option>  
    <option  value="MO">MO</option>
    <option value="MS" >MS</option>
    <option value="MT" >MT</option>
    <option value="NC" >NC</option> 
    <option  value="ND">ND</option>
    <option value="NE" >NE</option>
    <option value="NH" >NH</option>
    <option value="NJ" >NJ</option>
    <option value="NM" >NM</option>  
    <option value="NV" >NV</option>
    <option value="NY" >NY</option>
    <option value="OH" >OH</option>
    <option value="OK" >OK</option>
    <option value="OR" >OR</option>
    <option value="PA" >PA</option>
    <option value="RI" >RI</option>
    <option value="SC" >SC</option>  
    <option value="SD" >SD</option>
    <option value="TN" >TN</option>  
    <option value="TX" >TX</option>  
    <option value="UT" >UT</option>
    <option value="VA" >VA</option>  
    <option value="VT" >VT</option>   
    <option value="WA" >WA</option>
    <option value="WI" >WI</option>  
    <option value="WY" >WY</option>  

<label for="ZipCode">Zip Code:</label>
<input type="text" class="form-control" id="ZipCode" placeholder="Enter zip code" name="ZipCode"> 
<label for="Phone">Phone:</label>
<input type="text" class="form-control" id="Phone" placeholder="Enter phone #" name="Phone">  
<label for="email">Email:</label>
<input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
<label for="RoastType" class="form-label">Coffee Roast type (move slider to change, submit to select):</label><br>
<input type="range" oninput="changeRoastType()" list="tickmarks" id="RoastType"  name="RoastType" value="0" min="0" max="50" step="10" style="width: 400px;">

<datalist id="tickmarks">
<option value="0" label="light" >light</option>
<option value="10" >medium light</option>
<option value="20" >medium</option>
<option value="30" >medium dark</option>
<option value="40" >dark</option>
<option value="50" >extra dark</option>
</datalist>
<input type="color" id="roastColor" name="roastColor" value="#ffbb55">
Roast type: <input type="text" name="roastName" id="roastName" size="40" readonly value="Light">
<button type="submit" class="btn btn-info">Submit</button>
</div> 


</form>

<script>
   
 setInterval(updateTime,1000);

  function updateTime()
 {
    const dt=new Date();
    let h=(dt.getHours() % 12 > 0)?dt.getHours() % 12:12;
    let m=(dt.getMinutes() < 10)?("0"+dt.getMinutes().toString()):dt.getMinutes();
    let s=(dt.getSeconds() < 10)?("0"+dt.getSeconds().toString()):dt.getSeconds();
    let todayDate=dt.toLocaleDateString();
    document.getElementById("timePosition").innerHTML=todayDate.padEnd(25,' ')  + ( h + ":" + m + ":" + s);
 }

 function changeRoastType()
 {
    let roastType=document.getElementById("RoastType").value; //range 0 to 50
    let roastColor=document.getElementById("roastColor").value; //hexadecimal values represent color of roast
       let hexString=roastColor.toString(16);
    let r=hexString.substring(1,3);
   let g=hexString.substring(3,5);
    let b=hexString.substring(5,7);
   let rDec=parseInt(r,16);
   let gDec=parseInt(g,16);
   let bDec=parseInt(b,16);
    let nRoastType=parseInt(roastType);
    rDec = 255-(nRoastType * 2);
    gDec = 185-(nRoastType * 2);
    rHex=rDec.toString(16);
    gHex=gDec.toString(16);
    hexString="#" + rHex + gHex + hexString.substring(5,7);
    document.getElementById("roastColor").value=hexString;
    switch (roastType)
    {
        case "0":
            document.getElementById("roastName").value="Light";
            break;
        case "10":
            document.getElementById("roastName").value="Medium Light";
            break;
        case "20":
            document.getElementById("roastName").value="Medium";
            break;
        case "30":
            document.getElementById("roastName").value="Medium Dark";
            break;
        case "40":
            document.getElementById("roastName").value="Dark";
            break;
        case "50":
            document.getElementById("roastName").value="Extra Dark";
            break;
    }
}
    </script>
    </body>
</html>