<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Michroma">
<style>
 p {
       font-family:Michroma;
       font-size: 35px;
       font-weight:bold; 
 }
</style>
</head>
<body>

<?php
       $fName=$_POST['FirstName'];
        $lName=$_POST['LastName'];
        $address=$_POST['Address'];
        $city=$_POST['City'];
        $state=$_POST['State'];
        $zipCode=$_POST['ZipCode'];
        $phone=$_POST['Phone'];
        $email=$_POST['email'];
        $roastName=$_POST['roastName'];
        $dataLine=$fName.",";
        $dataLine .= $lName . ",";
        $dataLine .=$address.",";
        $dataLine .= $city . ",";
        $dataLine .= $state . ",";
        $dataLine .=$zipCode.",";
        $dataLine .=$phone.",";
        $dataLine .= $email.",";
        $dataLine .= $roastName;
        
        $fContact=fopen("ContactInfo.csv", "a");
        fwrite($fContact, $dataLine . "\n");
        fclose($fContact);
        echo "<p>Your contact information posted successfully.</p>";
        
?>
<center><a href="CSGLanding.php" style="font-size:30px;">Back to main page</a></center>
</body>
</html>